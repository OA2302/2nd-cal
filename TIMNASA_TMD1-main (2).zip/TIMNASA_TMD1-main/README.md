<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="left">
<a href="https://timnasa-session-id-9as4.onrender.com"><img src="https://img.shields.io/badge/Pair%20session%20code-white" alt="𝗽𝗮𝗶𝗿 𝘀𝗲𝘀𝘀𝗶𝗼𝗻 𝗶𝗱 𝟮" width="300"></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

<p align="center">
  <!-- GitHub Repo Activity Stats -->
  <img src="https://github-readme-stats.vercel.app/api?username=Qartde&show_icons=true&hide_title=true&count_private=true&hide=prs&theme=radical" alt="GitHub Repo Stats" width="800">

  <!-- Repo Activity Stats Screen -->
  <img src="https://github-readme-stats.vercel.app/api/pin/?username=Next5x&repo=Next5x/timnasa" alt="Pinned GitHub Repo Activity" width="800"> 
  # ☉︎𝚃𝙸𝙼𝙽𝙰𝚂𝙰 𝚃𝙴𝙲𝙷☉︎ ©𝟸𝟶𝟸𝟻
  █▄▄ ███ █▄▄█▄▄ ███ █▄▄
  █▄▄ ███ █▄▄█▄▄ ███ █▄▄
  
![](gravity.gif)
   
   <a href="https://signup.heroku.com/"><img title="CREATE-ACCOUNT" src="https://img.shields.io/badge/CREATE-ACCOUNT-h?color=green&style=for-the-badge&logo=red" width="180" height="43.45"/></a></p>

   ☢️IF YOU ALREADY HAVE A HEROKU ACCOUNT...DEPLOY NOW
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
 <a href="https://dashboard.heroku.com/new?template=https://github.com/Next5x/TIMNASA_TMD1"><img title="DEPLOY-ON HEROKU" src="https://img.shields.io/badge/DEPLOY-ON HEROKU-h?color=red&style=for-the-badge&logo=nike" width="220" height="38.45"/></a></p>

 
 [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&size=30&pause=1000&color=0000FF&center=true&vCenter=true&width=815&height=60&lines=▭+▬+▭+▬+▭+▬+▭+▬+▭+▬+▭)](https://git.io/typing-svg) 

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

[____________________________________________________]


[![JOIN WHATSAPP GROUP](https://raw.githubusercontent.com/Neeraj-x0/Neeraj-x0/main/photos/suddidina-join-whatsapp.png)](https://whatsapp.com/channel/0029VajweHxKQuJP6qnjLM31)

 





<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## 𝚃𝙸𝙼𝙽𝙰𝚂𝙰 𝙲𝙾𝙽𝚃𝙰𝙲𝚃
#   b o t  
 